#!/usr/bin/python3
#coding=utf-8

from PySide2.QtWidgets import *
from PySide2.QtCore import *
from PySide2.QtGui import *
from addDeviceFrame import *
import sys
import time
import os
import requests
import json

# 定义线程实现刷新进度栏
class RunThread(QThread):

    # 定义一个信号
    counter_value = Signal(int)

    def __init__(self, parent=None, counter_start=0):
        super().__init__(parent)
        self.counter = counter_start
        self.is_running = True

    def run(self):
        while self.counter < 100 and self.is_running:
            time.sleep(0.1)
            self.counter += 1
            print(self.counter)
            # 发射信号
            self.counter_value.emit(self.counter)

    def stop(self):
        self.is_running = False
        print('线程停止中...')
        self.terminate()

class MainDialog(QDialog, Ui_AddDeviceDialog):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.chooseFileButton.clicked.connect(self.choose_file)
        self.jwt = ''
        self.host = '127.0.0.2'
        self.port = '8080'
        self.filename = ''
        self.user = ''
        self.password = ''
        self.apps = []
        self.devprofiles = []
        self.read_host()
        if self.login() == False:
            self.info_log('登录服务器失败.\n请核实服务器IP和用户名密码.')
        else:
            self.info_log('登录服务器成功.')
            self.get_apps()
            self.get_dev_profiles()

    # 在textbrowser最后显示信息并移动光标到末尾
    def info_log(self, msg):
        self.infoText.append(msg)
        self.infoText.moveCursor(self.infoText.textCursor().End)

    # 从文件server.txt中获取服务器ip并在UI上显示
    # 同时获取用户名和密码
    def read_host(self):
        with open('server.txt', 'r') as f:
            hstr = f.readline().strip()
            if len(hstr) > 0:
                self.host = hstr
                print('self.host=', self.host)
            self.user = f.readline().strip()
            self.password = f.readline().strip()
            print('user:%s, password:%s' % (self.user, self.password))

        self.ServerIPText.setText(self.host)

    # 用指定用户名和密码登录服务器，获取jwt
    # 若无法登录（服务器故障或者用户名密码错误）则弹出对话框提示并退出
    def login(self):
        baseurl = 'http://' + self.host + ':' + self.port
        url = baseurl + '/api/internal/login'
        data = {"username":self.user, "password":self.password}
        val = json.dumps(data)
        print(url)
        print(val)

        try:
            res = requests.post(url, data=val)
            print(res.text)
            self.jwt = json.loads(res.text)['jwt']
            return True
        except Exception as e:
            print(e)
            return False

    # 获取应用列表并更新控件内容
    def get_apps(self):
        baseurl = 'http://' + self.host + ':' + self.port
        url = baseurl + '/api/applications'
        data = {"limit":"20", "offset":"0"}

        res = requests.get(url, params=data, headers={'Authorization':'Bearer '+self.jwt, 'Accept':'application/json'})
        ret = json.loads(res.text)
        
        print(ret)
        self.apps = ret['result']
        # 更新下拉框
        for app in self.apps:
            self.appsComboBox.addItem(app['name'])
        self.appsComboBox.setCurrentIndex(0)

    # 获取设备配置列表并更新控件内容
    def get_dev_profiles(self):
        baseurl = 'http://' + self.host + ':' + self.port
        url = baseurl + '/api/device-profiles'
        data = {"limit":"20", "offset":"0"}

        res = requests.get(url, params=data, headers={'Authorization':'Bearer '+self.jwt, 'Accept':'application/json'})
        ret = json.loads(res.text)
        
        print(ret)
        self.devprofiles = ret['result']
        # 更新下拉框
        for devpf in self.devprofiles:
            self.devprofileComboBox.addItem(devpf['name'])
        self.devprofileComboBox.setCurrentIndex(0)


    # 打开设备数据文件
    # xls表格，列分别为：devEUI, 名称, 描述, appkey
    def choose_file(self, event):
        fname, ftype = QFileDialog.getOpenFileName(self, '选取文件', os.getcwd(),
                "ExcelFile(*.xls *.xlsx);;AllFiles(*.*)")
        print('fname=%s, ftype=%s' % (fname, ftype))
        self.filename = fname
        self.filePathText.setText(self.filename)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    dlg = MainDialog()
    dlg.exec_()
